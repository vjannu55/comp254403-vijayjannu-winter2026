COMP254 Lab 5 - Exercise 1
Student: Vijay Jannu

Chosen operation: inorderNext(p)

Algorithm idea:
1. If p has a right child, the next position in inorder is the leftmost node in p's right subtree.
2. Otherwise, move up using parent references until we find an ancestor for which p is in the left subtree.
3. That ancestor is the next node in inorder.
4. If no such ancestor exists, return null.

Worst-case running time:
O(h), where h is the height of the tree.
In the worst case of a skewed tree, h = n, so the time is O(n).
