import java.util.List;

public class Exercise1Main {

    public static void main(String[] args) {
        LinkedBinaryTree<String> tree = new LinkedBinaryTree<>();

        // Build a sample tree.
        //            A
        //         /     \
        //        B       C
        //      /   \    / \
        //     D     E  F   G
        LinkedBinaryTree.Node<String> a = tree.addRoot("A");
        LinkedBinaryTree.Node<String> b = tree.addLeft(a, "B");
        LinkedBinaryTree.Node<String> c = tree.addRight(a, "C");
        LinkedBinaryTree.Node<String> d = tree.addLeft(b, "D");
        LinkedBinaryTree.Node<String> e = tree.addRight(b, "E");
        LinkedBinaryTree.Node<String> f = tree.addLeft(c, "F");
        LinkedBinaryTree.Node<String> g = tree.addRight(c, "G");

        System.out.println("Inorder traversal of the tree:");
        List<LinkedBinaryTree.Node<String>> inorder = tree.inorderPositions();
        for (LinkedBinaryTree.Node<String> node : inorder) {
            System.out.print(node.getElement() + " ");
        }
        System.out.println("\n");

        System.out.println("Testing inorderNext(p):");
        for (LinkedBinaryTree.Node<String> node : inorder) {
            LinkedBinaryTree.Node<String> next = tree.inorderNext(node);
            System.out.println("inorderNext(" + node.getElement() + ") = "
                    + (next == null ? "null" : next.getElement()));
        }

        System.out.println("\nWorst-case running time: O(h), where h is the height of the tree.");
        System.out.println("For a skewed tree, h can be n, so worst-case time becomes O(n).");

        // quick individual checks
        System.out.println("\nExtra checks:");
        System.out.println("inorderNext(D) should be B: " + tree.inorderNext(d).getElement());
        System.out.println("inorderNext(E) should be A: " + tree.inorderNext(e).getElement());
        System.out.println("inorderNext(G) should be null: " + tree.inorderNext(g));
        System.out.println("inorderNext(F) should be C: " + tree.inorderNext(f).getElement());
    }
}
