import java.util.ArrayList;
import java.util.List;

/**
 * Exercise 1 support class.
 * A simple linked binary tree with parent references.
 */
public class LinkedBinaryTree<E> {

    public static class Node<E> {
        private E element;
        private Node<E> parent;
        private Node<E> left;
        private Node<E> right;

        public Node(E element, Node<E> parent, Node<E> left, Node<E> right) {
            this.element = element;
            this.parent = parent;
            this.left = left;
            this.right = right;
        }

        public E getElement() {
            return element;
        }
    }

    private Node<E> root;
    private int size;

    public Node<E> root() {
        return root;
    }

    public int size() {
        return size;
    }

    public Node<E> addRoot(E element) {
        if (root != null) {
            throw new IllegalStateException("Tree already has a root");
        }
        root = new Node<>(element, null, null, null);
        size = 1;
        return root;
    }

    public Node<E> addLeft(Node<E> parent, E element) {
        if (parent.left != null) {
            throw new IllegalStateException("Left child already exists");
        }
        parent.left = new Node<>(element, parent, null, null);
        size++;
        return parent.left;
    }

    public Node<E> addRight(Node<E> parent, E element) {
        if (parent.right != null) {
            throw new IllegalStateException("Right child already exists");
        }
        parent.right = new Node<>(element, parent, null, null);
        size++;
        return parent.right;
    }

    public Node<E> left(Node<E> node) {
        return node.left;
    }

    public Node<E> right(Node<E> node) {
        return node.right;
    }

    public Node<E> parent(Node<E> node) {
        return node.parent;
    }

    /**
     * Returns the position visited immediately after p in an inorder traversal,
     * or null if p is the last node visited.
     *
     * Worst-case running time: O(h), where h is the tree height.
     * In the worst case for a skewed tree, this becomes O(n).
     */
    public Node<E> inorderNext(Node<E> p) {
        if (p == null) {
            return null;
        }

        // Case 1: if there is a right subtree, go to its leftmost node.
        if (p.right != null) {
            Node<E> walk = p.right;
            while (walk.left != null) {
                walk = walk.left;
            }
            return walk;
        }

        // Case 2: move upward until p is a left child of its parent.
        Node<E> walk = p;
        Node<E> ancestor = walk.parent;
        while (ancestor != null && walk == ancestor.right) {
            walk = ancestor;
            ancestor = ancestor.parent;
        }
        return ancestor;
    }

    public List<Node<E>> inorderPositions() {
        List<Node<E>> snapshot = new ArrayList<>();
        inorderSubtree(root, snapshot);
        return snapshot;
    }

    private void inorderSubtree(Node<E> node, List<Node<E>> snapshot) {
        if (node == null) {
            return;
        }
        inorderSubtree(node.left, snapshot);
        snapshot.add(node);
        inorderSubtree(node.right, snapshot);
    }
}
