COMP254 Lab 5 - Exercise 2
Student: Vijay Jannu

Algorithm idea:
Use a postorder traversal.
- Recursively compute the left subtree height.
- Recursively compute the right subtree height.
- The height of the current node is max(leftHeight, rightHeight) + 1.
- Print the element and the computed height during the postorder visit.

Leaf rule:
A leaf has height 0.

Worst-case running time:
O(n), because each node is visited once.
