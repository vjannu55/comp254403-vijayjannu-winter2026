public class Exercise2Main {

    public static void main(String[] args) {
        LinkedBinaryTree<String> tree = new LinkedBinaryTree<>();

        // Build a sample tree.
        //            A
        //         /     \
        //        B       C
        //      /   \      \
        //     D     E      F
        //                   \
        //                    G
        LinkedBinaryTree.Node<String> a = tree.addRoot("A");
        LinkedBinaryTree.Node<String> b = tree.addLeft(a, "B");
        LinkedBinaryTree.Node<String> c = tree.addRight(a, "C");
        tree.addLeft(b, "D");
        tree.addRight(b, "E");
        LinkedBinaryTree.Node<String> f = tree.addRight(c, "F");
        tree.addRight(f, "G");

        System.out.println("Postorder output: element followed by subtree height\n");
        int overallHeight = tree.printElementAndSubtreeHeight(tree.root());

        System.out.println("\nOverall tree height: " + overallHeight);
        System.out.println("Worst-case running time: O(n)");
    }
}
