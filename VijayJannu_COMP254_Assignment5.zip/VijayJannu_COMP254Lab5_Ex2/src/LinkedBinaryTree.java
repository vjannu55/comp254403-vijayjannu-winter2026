/**
 * Exercise 2 support class.
 * A simple linked binary tree for postorder height computation.
 */
public class LinkedBinaryTree<E> {

    public static class Node<E> {
        private E element;
        private Node<E> parent;
        private Node<E> left;
        private Node<E> right;

        public Node(E element, Node<E> parent, Node<E> left, Node<E> right) {
            this.element = element;
            this.parent = parent;
            this.left = left;
            this.right = right;
        }

        public E getElement() {
            return element;
        }
    }

    private Node<E> root;

    public Node<E> addRoot(E element) {
        root = new Node<>(element, null, null, null);
        return root;
    }

    public Node<E> addLeft(Node<E> parent, E element) {
        parent.left = new Node<>(element, parent, null, null);
        return parent.left;
    }

    public Node<E> addRight(Node<E> parent, E element) {
        parent.right = new Node<>(element, parent, null, null);
        return parent.right;
    }

    public Node<E> root() {
        return root;
    }

    /**
     * Postorder algorithm that computes and prints the subtree height for every node.
     * Height of a leaf is 0.
     * Running time: O(n), because each node is visited exactly once.
     */
    public int printElementAndSubtreeHeight(Node<E> node) {
        if (node == null) {
            return -1; // so a leaf becomes max(-1,-1)+1 = 0
        }

        int leftHeight = printElementAndSubtreeHeight(node.left);
        int rightHeight = printElementAndSubtreeHeight(node.right);
        int currentHeight = Math.max(leftHeight, rightHeight) + 1;

        System.out.println("Element: " + node.getElement() + ", Subtree Height: " + currentHeight);
        return currentHeight;
    }
}
