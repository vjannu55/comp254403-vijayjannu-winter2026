/*
 * Modified from the provided Week 9 example code.
 * Exercise 3 requirement: implement upheap recursively with no loop.
 */
import java.util.ArrayList;
import java.util.Comparator;

public class HeapPriorityQueue<K,V> extends AbstractPriorityQueue<K,V> {
  protected ArrayList<Entry<K,V>> heap = new ArrayList<>();

  public HeapPriorityQueue() { super(); }

  public HeapPriorityQueue(Comparator<K> comp) { super(comp); }

  public HeapPriorityQueue(K[] keys, V[] values) {
    super();
    for (int j = 0; j < Math.min(keys.length, values.length); j++)
      heap.add(new PQEntry<>(keys[j], values[j]));
    heapify();
  }

  protected int parent(int j) { return (j - 1) / 2; }
  protected int left(int j) { return 2 * j + 1; }
  protected int right(int j) { return 2 * j + 2; }
  protected boolean hasLeft(int j) { return left(j) < heap.size(); }
  protected boolean hasRight(int j) { return right(j) < heap.size(); }

  protected void swap(int i, int j) {
    Entry<K,V> temp = heap.get(i);
    heap.set(i, heap.get(j));
    heap.set(j, temp);
  }

  /**
   * Recursive version of upheap.
   * Do a single upward swap and recur if necessary.
   * Worst-case running time: O(log n).
   */
  protected void upheap(int j) {
    if (j == 0) {
      return; // already at the root
    }

    int p = parent(j);
    if (compare(heap.get(j), heap.get(p)) < 0) {
      swap(j, p);
      upheap(p);
    }
  }

  protected void downheap(int j) {
    while (hasLeft(j)) {
      int leftIndex = left(j);
      int smallChildIndex = leftIndex;
      if (hasRight(j)) {
        int rightIndex = right(j);
        if (compare(heap.get(leftIndex), heap.get(rightIndex)) > 0)
          smallChildIndex = rightIndex;
      }
      if (compare(heap.get(smallChildIndex), heap.get(j)) >= 0)
        break;
      swap(j, smallChildIndex);
      j = smallChildIndex;
    }
  }

  protected void heapify() {
    int startIndex = parent(size() - 1);
    for (int j = startIndex; j >= 0; j--)
      downheap(j);
  }

  @Override
  public int size() { return heap.size(); }

  @Override
  public Entry<K,V> min() {
    if (heap.isEmpty()) return null;
    return heap.get(0);
  }

  @Override
  public Entry<K,V> insert(K key, V value) throws IllegalArgumentException {
    checkKey(key);
    Entry<K,V> newest = new PQEntry<>(key, value);
    heap.add(newest);
    upheap(heap.size() - 1);
    return newest;
  }

  @Override
  public Entry<K,V> removeMin() {
    if (heap.isEmpty()) return null;
    Entry<K,V> answer = heap.get(0);
    swap(0, heap.size() - 1);
    heap.remove(heap.size() - 1);
    if (!heap.isEmpty()) {
      downheap(0);
    }
    return answer;
  }

  public void printHeap() {
    for (int i = 0; i < heap.size(); i++) {
      System.out.println("(" + heap.get(i).getKey() + ", " + heap.get(i).getValue() + ")");
    }
  }

  public static void main(String[] args) {
    HeapPriorityQueue<Integer, String> heapQueue = new HeapPriorityQueue<>();

    heapQueue.insert(47, "A");
    heapQueue.insert(75, "C");
    heapQueue.insert(28, "B");
    heapQueue.insert(51, "D");
    heapQueue.insert(31, "F");
    heapQueue.insert(22, "G");
    heapQueue.insert(15, "H");

    System.out.println("Heap after recursive upheap insertions:");
    heapQueue.printHeap();

    System.out.println("\nMinimum key: " + heapQueue.min().getKey());
    System.out.println("Worst-case running time of recursive upheap: O(log n)");
  }
}
