COMP254 Lab 5 - Exercise 3
Student: Vijay Jannu

This project uses the provided Week 9 example code for HeapPriorityQueue.
The upheap method was rewritten using recursion and no loop.

Recursive idea:
1. If the current index is the root, stop.
2. Compare the entry with its parent.
3. If the child key is smaller, swap once.
4. Recur on the parent index.

Worst-case running time:
O(log n), because the recursive call can move up at most one level per step in the heap.
